"use strict";

var Age, first, last, email, phone, address, country, grade1, grade2, grade3, grade4, grade5, grade6, grade7, grade8, sub1, sub2, sub3, sub4, sub5, sub6;

function getscholarship() {
    // gGet user Values
    var Age = document.getElementById('Age').value
    var first = document.getElementById('Firstname').value;
    var last = document.getElementById('Surname').value;
    var email = document.getElementById('Email').value;
    var phone = document.getElementById('Number').value;
    var address = document.getElementById('Address').value;
    var country = document.getElementById('Country').value;
    var grade1 = document.getElementById('score1').value;
    var grade2 = document.getElementById('score2').value;
    var grade3 = document.getElementById('score3').value;
    var grade4 = document.getElementById('score4').value;
    var grade5 = document.getElementById('score5').value;
    var grade6 = document.getElementById('score6').value;
    var grade7 = document.getElementById('score7').value;
    var grade8 = document.getElementById('score8').value;
    var sub1 = document.getElementById('sub1').value;
    var sub2 = document.getElementById('sub2').value;
    var sub3 = document.getElementById('sub3').value;
    var sub4 = document.getElementById('sub4').value;
    var sub5 = document.getElementById('sub5').value;
    var sub6 = document.getElementById('sub6').value;




    // Get Total score

    Student_total = parseInt(grade1) + parseInt(grade2) + parseInt(grade3) + parseInt(grade4) + parseInt(grade5) + parseInt(grade6) + parseInt(grade7) + parseInt(grade8);

    // Average_Score
    Student_average = Student_total / 8;


    // Agepoints
    const age = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40];
    for (let i = 0; i < age.length; i++) {
        let AgePoint = 0;
        if (age[i] <= 24) {
            AgePoint = 100;
        };
        if (age[i] <= 30) {
            AgePoint = 100;
        };
        if (age[i] <= 35) {
            AgePoint = 50;
        };


        if (age[i] <= 40) {
            AgePoint = 30;

        } else {
            AgePoint = 10;

        };

    };



    // Country Point

    if (Country == 1) {
        country_point = 50;
    }
    if (Country == 2) {
        country_point = 40;
    }
    if (Country == 3) {
        country_point = 30;
    }
    if (Country == 4) {
        country_point = 20;
    }
    if (Country == 5) {
        country_point = 10;
    }


    // Grandtotal

    Grand_total = country_point + AgePoint + Student_average

    // Compare averageScore



    if (avg >= 90 && avg <= 100) {
        avg_point = 150;
    }
    if (avg >= 85 && avg <= 89) {
        avg_point = 140;
    }
    if (avg >= 75 && avg <= 84) {
        avg_point = 120;
    }
    if (avg >= 65 && avg <= 74) {
        avg_point = 100;
    }
    if (avg >= 60 && avg <= 64) {
        avg_point = 80;
    }
    if (avg >= 50 && avg <= 59) {
        avg_point = 50;
    }
    if (avg >= 40 && avg <= 49) {
        avg_point = 20;
    }


    document.getElementById('submit_button').onclick; {
        getscholarship()
        console.log(age);
        console.log(Student_total);
        alert('hello');
    };

    document.getElementById('last').innerHTML = Grand_total;
    console.log(Grand_total);
};